

```python
import pandas as pd
import numpy as np
import subprocess

import matplotlib.pyplot as plt
import matplotlib

```


```python
import pandas as pd
import numpy as np
import subprocess

import matplotlib.pyplot as plt
import matplotlib

from IPython.display import display, display_html


%matplotlib inline
# matplotlib.rcParams['figure.figsize'] = (13.0, 4.0)
# matplotlib.style.use('ggplot')
pd.options.display.max_rows = 15

def generate_data(algorithm, config, dependance_param, step, max):
    subprocess.run(["rm", "-f", "out", "out.tmp", "out.csv.tmp"])

    id_inst = config['id_inst']
    config['repetition'] = 0
    additive = pd.DataFrame({dependance_param: {}})
    for cval in np.arange(config[dependance_param], max, step):
        config[dependance_param] = cval
        no_instances = config['instances']
        output = subprocess.check_output(f"../../knapsack-generator/knapgen -I {id_inst} -n {config['items']} -N {config['instances']} -m {config['capacityratio']} -W {config['maxweight']} -C {config['maxprice']} -k {config['exp']} -d {config['balance']} >> out.tmp 2> /dev/null", shell=True)
        for i in range(id_inst, id_inst + no_instances):
            additive = additive.append(pd.DataFrame({dependance_param: {i: config[dependance_param]}}))
        id_inst += config['instances']
        
    output = subprocess.check_output(f"../../src/knapsack-problem.py -p out.tmp {algorithm} > out.csv.tmp", shell=True)
    result = pd.read_csv('out.csv.tmp')
    return result.join(additive)

def create_statistics(algorithm, data, dependance_param):
    fig, axes = matplotlib.pyplot.subplots(nrows=1, ncols=1)

    timedep = data.groupby(dependance_param).mean()[['time_ms']]
    axes.set_title('{} - Dependance of {} on {}'.format(algorithm,'time [ms]', dependance_param))
    axes.set_ylabel("Computation time [ms]")
    axes.plot(timedep, marker = 'o', ls = ':', color = 'silver', markerSize = 8, markerfacecolor = 'blue', markeredgecolor = 'indianred')
    # print(timedep.to_csv())
    plt.savefig(f'graphs/time_on_{dependance_param}_{algorithm}', bbox_inches='tight')                            
    fig_price, axes_price = matplotlib.pyplot.subplots(nrows=1, ncols=1)
                                    
    qual = data.groupby(dependance_param).mean()[['price']]
    axes_price.set_title('{} - Dependance of {} on {}'.format(algorithm, 'price', dependance_param))
    axes_price.set_ylabel("Price")
    
    axes_price.plot(qual, marker = 'o', ls = ':', color = 'silver', markerSize = 8, markerfacecolor = 'green', markeredgecolor = 'rebeccapurple')
    plt.savefig(f'graphs/price_on_{dependance_param}_{algorithm}', bbox_inches='tight')                            

    return {
        'time_min_ms': float(timedep[['time_ms']].min()),
        'time_max_ms': float(timedep[['time_ms']].max()),
        'time_amplitude': float(timedep[['time_ms']].max()-timedep[['time_ms']].min()),
        'price_min': float(qual[['price']].min()),
        'price_max': float(qual[['price']].max()),
        'price_amplitude': float(qual[['price']].max()-qual[['price']].min()),
    }

def experiment(name, config, dependance_param, step, max):
    # display_html('<h2 id="experiment-{}">[{}] {}</h2>'.format(globaleid, globaleid, name), raw=True)
    # display_html('<h2 id="experiment-{}">[{}] {}</h2>'.format(globaleid, globaleid, name), raw=True)
    print(f'experiment - {name}')
    print(pd.DataFrame([config]))
    
    data = generate_data(config['algorithm'], config, dependance_param, step, max)
    data = data.set_index('knapsack_id')
    
    stats = create_statistics(name, data, dependance_param)
    print(pd.DataFrame([stats]))    
```


```python
experiment('recursive', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 4, 'instances': 1, 
                               'capacityratio': 0.5, 'maxweight': 200, 'maxprice': 200, 
                               'exp': 3, 'balance': 0 }, 
            'repetition', 1, 50)


```

    experiment - recursive
       algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  heuristic        0            0.5    3        0          1      4   
    
       maxprice  maxweight  
    0       200        200  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0              0.0      355.0      355.0        0.024319     0.032187   
    
       time_min_ms  
    0     0.007868  



![png](output_2_1.png)



![png](output_2_2.png)



```python
# experiment('sum vysledku, rekurzivne, prumer 250 instanci / opakovani', { 'algorithm': 'recursive', 'id_inst': 0, 'items': 4, 'instances': 250, 
#                                'capacityratio': 0.5, 'maxweight': 200, 'maxprice': 200, 
#                                'exp': 3, 'balance': 0 }, 'repetition', 1, 50)

experiment('balance +1, dynamic programming', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 1 }, 'exp', 0.005, 1)
```

    experiment - balance +1, dynamic programming
      algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0   dynamic        1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             97.2      421.6      324.4        0.999308     2.388668   
    
       time_min_ms  
    0      1.38936  



![png](output_3_1.png)



![png](output_3_2.png)



```python
experiment('sum vysledku, recurisve, avg 250 instances - repetitions', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 4, 'instances': 250, 
                               'capacityratio': 0.5, 'maxweight': 200, 'maxprice': 200, 
                               'exp': 3, 'balance': 0 }, 'repetition', 1, 50)
```

    experiment - sum vysledku, recurisve, avg 250 instances - repetitions
         algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  brute_force        0            0.5    3        0        250      4   
    
       maxprice  maxweight  
    0       200        200  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0           18.368    265.252    246.884        0.096978     0.126972   
    
       time_min_ms  
    0     0.029994  



![png](output_4_1.png)



![png](output_4_2.png)



```python
# Capacity ratio

experiment('dynamic', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 4, 'balance': 0 }, 'capacityratio', 0.005, 0.95)
```

    experiment - dynamic
      algorithm  balance  capacityratio  exp  id_inst  instances  items  maxprice  \
    0   dynamic        0           0.05    4        0          5     10       100   
    
       maxweight  
    0        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            351.8      444.8       93.0        3.818941     4.225683   
    
       time_min_ms  
    0     0.406742  



![png](output_5_1.png)



![png](output_5_2.png)



```python
experiment('brute_force', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 4, 'balance': 0 }, 'capacityratio', 0.005, 0.95)
```

    experiment - brute_force
         algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  brute_force        0           0.05    4        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            417.6      498.0       80.4        1.167488     2.950811   
    
       time_min_ms  
    0     1.783323  



![png](output_6_1.png)



![png](output_6_2.png)



```python
experiment('heuristic', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 1, 'balance': 0 }, 'capacityratio', 0.005, 0.95)
```

    experiment - heuristic
       algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  heuristic        0           0.05    1        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            355.0      454.4       99.4        0.065231     0.075626   
    
       time_min_ms  
    0     0.010395  



![png](output_7_1.png)



![png](output_7_2.png)



```python
experiment('branch_and_bound', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 6, 'balance': 0 }, 'capacityratio', 0.005, 0.95)
```

    experiment - branch_and_bound
          algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  branch_bound        0           0.05    6        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            478.4      559.2       80.8        0.267267     0.307608   
    
       time_min_ms  
    0      0.04034  



![png](output_8_1.png)



![png](output_8_2.png)



```python
# Max weight

experiment('heuristic', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 50, 
                               'capacityratio': 0.5, 'maxweight': 15, 'maxprice': 25, 
                               'exp': 4, 'balance': 0 }, 'maxweight', 5, 200)
```

    experiment - heuristic
       algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  heuristic        0            0.5    4        0         50     10   
    
       maxprice  maxweight  
    0        25         15  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             7.96      96.52      88.56        0.013213     0.024734   
    
       time_min_ms  
    0      0.01152  



![png](output_9_1.png)



![png](output_9_2.png)



```python
# Max weight

experiment('branch_bound', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 25, 
                               'capacityratio': 0.5, 'maxweight': 15, 'maxprice': 25, 
                               'exp': 4, 'balance': 0 }, 'maxweight', 5, 200)
```

    experiment - branch_bound
          algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  branch_bound        0            0.5    4        0         25     10   
    
       maxprice  maxweight  
    0        25         15  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0              9.8     103.04      93.24        0.324821     0.534658   
    
       time_min_ms  
    0     0.209837  



![png](output_10_1.png)



![png](output_10_2.png)



```python
# Max weight

experiment('brute_force', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 25, 
                               'capacityratio': 0.5, 'maxweight': 15, 'maxprice': 25, 
                               'exp': 4, 'balance': 0 }, 'maxweight', 10, 1000)
```

    experiment - brute_force
         algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  brute_force        0            0.5    4        0         25     10   
    
       maxprice  maxweight  
    0        25         15  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            18.88     105.64      86.76         0.56181     2.361383   
    
       time_min_ms  
    0     1.799574  



![png](output_11_1.png)



![png](output_11_2.png)



```python
# Max weight

experiment('dynamic', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 12, 'instances': 10, 
                               'capacityratio': 0.5, 'maxweight': 15, 'maxprice': 25, 
                               'exp': 4, 'balance': 0 }, 'maxweight', 10, 1000)
```

    experiment - dynamic
      algorithm  balance  capacityratio  exp  id_inst  instances  items  maxprice  \
    0   dynamic        0            0.5    4        0         10     12        25   
    
       maxweight  
    0         15  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             24.0      130.1      106.1        1.169777     5.951762   
    
       time_min_ms  
    0     4.781985  



![png](output_12_1.png)



![png](output_12_2.png)



```python
# Max Price

experiment('brute force', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 10, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 10, 
                               'exp': 4, 'balance': 0 }, 'maxprice', 30, 3000)
```

    experiment - brute force
         algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  brute_force        0            0.5    4        0         10     10   
    
       maxprice  maxweight  
    0        10        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0          11797.8    11841.0       43.2       16.926479    18.745422   
    
       time_min_ms  
    0     1.818943  



![png](output_13_1.png)



![png](output_13_2.png)



```python
# Max Price

experiment('branch_bound', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 10, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 10, 
                               'exp': 4, 'balance': 0 }, 'maxprice', 30, 3000)
```

    experiment - branch_bound
          algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  branch_bound        0            0.5    4        0         10     10   
    
       maxprice  maxweight  
    0        10        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0          11943.0    11988.3       45.3        0.945878     1.136708   
    
       time_min_ms  
    0      0.19083  



![png](output_14_1.png)



![png](output_14_2.png)



```python
# Max Price

experiment('dynamic', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 10, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 10, 
                               'exp': 4, 'balance': 0 }, 'maxprice', 30, 3000)
```

    experiment - dynamic
      algorithm  balance  capacityratio  exp  id_inst  instances  items  maxprice  \
    0   dynamic        0            0.5    4        0         10     10        10   
    
       maxweight  
    0        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0          11541.0    11577.0       36.0      256.769776   258.064127   
    
       time_min_ms  
    0     1.294351  



![png](output_15_1.png)



![png](output_15_2.png)



```python
# Max Price

experiment('heuristic', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 10, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 10, 
                               'exp': 4, 'balance': 0 }, 'maxprice', 30, 3000)
```

    experiment - heuristic
       algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  heuristic        0            0.5    4        0         10     10   
    
       maxprice  maxweight  
    0        10        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0          11345.2    11380.6       35.4        0.009274     0.020361   
    
       time_min_ms  
    0     0.011086  



![png](output_16_1.png)



![png](output_16_2.png)



```python
# Capacity ratio

experiment('brute_force', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 4, 'balance': 0 }, 'capacityratio', 0.005, 0.95)
```

    experiment - brute_force
         algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  brute_force        0           0.05    4        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            518.2      566.0       47.8        26.38731    28.157663   
    
       time_min_ms  
    0     1.770353  



![png](output_17_1.png)



![png](output_17_2.png)



```python
# Capacity ratio

experiment('branch_bound', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 4, 'balance': 0 }, 'capacityratio', 0.005, 1)
```

    experiment - branch_bound
          algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  branch_bound        0           0.05    4        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            478.6      543.6       65.0        0.231361     0.262833   
    
       time_min_ms  
    0     0.031471  



![png](output_18_1.png)



![png](output_18_2.png)



```python
# Capacity ratio

experiment('heuristic', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 4, 'balance': 0 }, 'capacityratio', 0.005, 0.95)
```

    experiment - heuristic
       algorithm  balance  capacityratio  exp  id_inst  instances  items  \
    0  heuristic        0           0.05    4        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            376.4      491.6      115.2        0.761366     0.771379   
    
       time_min_ms  
    0     0.010014  



![png](output_19_1.png)



![png](output_19_2.png)



```python
# Capacity ratio

experiment('dynamic', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.05, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 4, 'balance': 0 }, 'capacityratio', 0.005, 1)
```

    experiment - dynamic
      algorithm  balance  capacityratio  exp  id_inst  instances  items  maxprice  \
    0   dynamic        0           0.05    4        0          5     10       100   
    
       maxweight  
    0        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            389.2      505.0      115.8        2.943945     3.311253   
    
       time_min_ms  
    0     0.367308  



![png](output_20_1.png)



![png](output_20_2.png)



```python
# Granularity
experiment('brute_force, bal: -1', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': -1 }, 'exp', 0.005, 1)
```

    experiment - brute_force, bal: -1
         algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  brute_force       -1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            137.2      460.4      323.2        0.647116     2.392769   
    
       time_min_ms  
    0     1.745653  



![png](output_21_1.png)



![png](output_21_2.png)



```python
# Granularity
experiment('brute_force, bal: 0', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 0 }, 'exp', 0.005, 1)
```

    experiment - brute_force, bal: 0
         algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  brute_force        0            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            113.0      446.2      333.2        2.658653     4.422426   
    
       time_min_ms  
    0     1.763773  



![png](output_22_1.png)



![png](output_22_2.png)



```python
# Granularity
experiment('brute_force, bal: 1', { 'algorithm': 'brute_force', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 1 }, 'exp', 0.005, 1)
```

    experiment - brute_force, bal: 1
         algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  brute_force        1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             89.6      420.8      331.2        0.837898     2.655077   
    
       time_min_ms  
    0     1.817179  



![png](output_23_1.png)



![png](output_23_2.png)



```python
# Granularity
experiment('dynamic, bal: -1', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': -1 }, 'exp', 0.005, 1)
# Granularity
experiment('dynamic, bal: 0', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 0 }, 'exp', 0.005, 1)
# Granularity
experiment('dynamic, bal: 1', { 'algorithm': 'dynamic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 1 }, 'exp', 0.005, 1)
```

    experiment - dynamic, bal: -1
      algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0   dynamic       -1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            111.6      458.2      346.6        0.906801     2.297974   
    
       time_min_ms  
    0     1.391172  
    experiment - dynamic, bal: 0
      algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0   dynamic        0            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             85.0      446.0      361.0        2.105713     3.466749   
    
       time_min_ms  
    0     1.361036  
    experiment - dynamic, bal: 1
      algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0   dynamic        1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            143.2      422.8      279.6         1.44577     2.821016   
    
       time_min_ms  
    0     1.375246  



![png](output_24_1.png)



![png](output_24_2.png)



![png](output_24_3.png)



![png](output_24_4.png)



![png](output_24_5.png)



![png](output_24_6.png)



```python
# Granularity
experiment('branch_bound, bal: -1', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': -1 }, 'exp', 0.005, 1)
# Granularity
experiment('branch_bound, bal: 0', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 0 }, 'exp', 0.005, 1)
# Granularity
experiment('branch_bound, bal: 1', { 'algorithm': 'branch_bound', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 1 }, 'exp', 0.005, 1)
```

    experiment - branch_bound, bal: -1
          algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  branch_bound       -1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            124.8      467.6      342.8        0.532007     0.629568   
    
       time_min_ms  
    0     0.097561  
    experiment - branch_bound, bal: 0
          algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  branch_bound        0            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             30.2      408.8      378.6        0.222492     0.399256   
    
       time_min_ms  
    0     0.176764  
    experiment - branch_bound, bal: 1
          algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  branch_bound        1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            112.8      441.8      329.0        0.647688     0.809097   
    
       time_min_ms  
    0     0.161409  



![png](output_25_1.png)



![png](output_25_2.png)



![png](output_25_3.png)



![png](output_25_4.png)



![png](output_25_5.png)



![png](output_25_6.png)



```python
# Granularity
experiment('heuristic, bal: -1', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': -1 }, 'exp', 0.005, 1)
# Granularity
experiment('heuristic, bal: 0', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 0 }, 'exp', 0.005, 1)
# Granularity
experiment('heuristic, bal: 1', { 'algorithm': 'heuristic', 'id_inst': 0, 'items': 10, 'instances': 5, 
                               'capacityratio': 0.5, 'maxweight': 100, 'maxprice': 100, 
                               'exp': 0.01, 'balance': 1 }, 'exp', 0.005, 1)
```

    experiment - heuristic, bal: -1
       algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  heuristic       -1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            152.2      452.4      300.2        0.036764     0.047541   
    
       time_min_ms  
    0     0.010777  
    experiment - heuristic, bal: 0
       algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  heuristic        0            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0             47.0      406.8      359.8        0.021124     0.032663   
    
       time_min_ms  
    0     0.011539  
    experiment - heuristic, bal: 1
       algorithm  balance  capacityratio   exp  id_inst  instances  items  \
    0  heuristic        1            0.5  0.01        0          5     10   
    
       maxprice  maxweight  
    0       100        100  
       price_amplitude  price_max  price_min  time_amplitude  time_max_ms  \
    0            133.2      428.4      295.2         0.02265     0.033045   
    
       time_min_ms  
    0     0.010395  



![png](output_26_1.png)



![png](output_26_2.png)



![png](output_26_3.png)



![png](output_26_4.png)



![png](output_26_5.png)



![png](output_26_6.png)



```python

```
